import "./App.css";

import Acceuil from "./Compont/Accueil";
import Profile from "./Compont/Profile";
import PublierAnnounce from "./Compont/PublierAnnounce";
import Favouris from "./Compont/Favouris1";
import { Routes, Route } from "react-router-dom";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Acceuil />} />
        <Route path="/Favouris1" element={<Favouris />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/publierAnnounce" element={<PublierAnnounce />} />
      </Routes>
    </div>
  );
}

export default App;
