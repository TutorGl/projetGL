import React from "react";
import logo from "./logo1.png";
import "./Up arrow.png";
import "./profile.css";
import { BrandFacebook } from "tabler-icons-react";
import { BrandTwitter } from "tabler-icons-react";
import { BrandLinkedin } from "tabler-icons-react";
import { BrandInstagram } from "tabler-icons-react";
function Footer() {
  return (
    <div className="footer">
      {" "}
      <div class="f1">
        <div cllassName="logo">
          <img src={logo} alt="logo" />
        </div>
        <p>
          TUTOR est un site web pour la publication et la consultation des
          annonces de soutien scolaire
        </p>
        <div class="list">
          <ul>
            <li>
              <a href="#">Acuiel</a>{" "}
            </li>
            <li>
              {" "}
              <a href="#">Liste de favouris</a>
            </li>
            <li>
              {" "}
              <a href="#">Cintcat us</a>
            </li>
            <li>
              {" "}
              <a href="#">Publier un announce</a>
            </li>{" "}
          </ul>
          ;
        </div>
        <div class="list">
          <ul>
            {" "}
            <li>
              <BrandFacebook size={20} strokeWidth={2} color={"#0081FE"} />
              <a href="#">facebook</a>
            </li>
            <li>
              <BrandTwitter size={20} strokeWidth={2} color={"#0081FE"} />
              <a href="#">Twitter</a>
            </li>
            <li>
              <BrandLinkedin size={20} strokeWidth={2} color={"#0081FE"} />
              <a href="#">Linkedin</a>
            </li>
            <li>
              {" "}
              <BrandInstagram size={20} strokeWidth={2} color={"#0081FE"} />
              <a href="#"> Instagram </a>
            </li>
          </ul>
        </div>
        <div class="up">
          {" "}
          <a href="#">
            <img src={require("./Up arrow.png")} />
          </a>
        </div>
      </div>
      <div class="right"> © 2022 Lift Media. All rights reserved.</div>
    </div>
  );
}

export default Footer;
