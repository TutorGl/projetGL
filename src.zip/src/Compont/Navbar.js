import React from "react";
import "../App.css";
import logo from "./logo1.png";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <div className="Navbar">
      <img cllassName="logo" src={logo} alt="logo" />
      <div>
        <input type="text" placeholder="search..." />
        <button>Search</button>
      </div>
      <div className="links">
        <Link to="/">Acceuil</Link>
        <Link to="/PublierAnnounce">publier un announce</Link>
        <Link to="/Favouris1">liste de favouris</Link>
        <Link to="/profile">Profile</Link>
      </div>
    </div>
  );
}

export default Navbar;
