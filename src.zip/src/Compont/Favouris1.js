import Navbar from "./Navbar";
import Favouris from "./Favouris";
import Footer from "./Footer";

export default function Favouris1() {
  return (
    <>
      <Navbar />
      <Favouris />
      <Footer />
    </>
  );
}
