import Navbar from "./Navbar";
import Image from "./Image";
import Footer from "./Footer";
import Annonces from "./Annonces";

export default function Acceuil() {
  return (
    <>
      <Navbar />
      <Image />
      <Annonces />
      <Footer />
    </>
  );
}
