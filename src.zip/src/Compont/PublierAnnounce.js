import "./StyleAnn.css";
import React, { useEffect, useState } from "react";
import Footer from "./Footer";
import Navbar from "./Navbar";

const PublierAnnounce = () => {
  const initialisation = {
    firstname: "",
    lastname: "",
    email: "",
    addresse: "",
    numero: "",
    image: "",
    desc: "",
    tarif: "",
    lieu: "",
    theme: "",
  };
  const [FormValues, setFormValues] = useState(initialisation);
  const [FormErrors, setFormErrors] = useState({});
  const [IsSubmit, setIsSubmit] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormValues({ ...FormValues, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setFormErrors(validate(FormValues));
    setIsSubmit(true);
  };
  useEffect(() => {
    console.log(FormErrors);
    if (Object.keys(FormErrors).length === 0 && IsSubmit) {
      console.log(FormValues);
    }
  }, [FormErrors]);
  const validate = (values) => {
    const errors = {};
    const regex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    if (!values.firstname) {
      errors.firstname = "Veuillez entrer votre nom !";
    }
    if (!values.lastname) {
      errors.lastname = "Veuillez entrer votre prénom !";
    }
    if (!values.addresse) {
      errors.addresse = " Veuillez entrer votre adresse !";
    }
    if (!values.numero) {
      errors.numero = "Veuillez entrez votre numero de téléphone !";
    }
    if (!values.email) {
      errors.email = " Veuillez entrer votre email!";
    } else if (!regex.test(values.email)) {
      errors.email = "le format de l'email est incorrect ";
    }
    if (!values.image) {
      errors.image = " Veuillez entrer une photo !";
    }
    if (!values.desc) {
      errors.desc = " Veuillez entrer une description sur cette formation !";
    }
    if (!values.tarif) {
      errors.tarif = "Veuillez entrer le tarif de cette formation !";
    }
    if (!values.lieu) {
      errors.lieu = "Veuillez entrer le lieu de cette formation !";
    }
    if (!values.theme) {
      errors.theme = "Veuillez entrer le thème de cette formation !";
    }
    return errors;
  };

  return (
    <div>
    <div>
    <Navbar></Navbar>
     </div>
    <div className="PublierAnnounce">

       
      <h1 id="h">publier une announce</h1>
      <p>pour publier une announce il faut remplir ce formualire</p>

      <form onSubmit={handleSubmit}>
        <div className="annonceur">
          <h2>les informations de l'annonceur:</h2>
          <div id="div1">
            <input
              type="text"
              placeholder="entrez votre nom"
              name="firstname"
              value={FormValues.firstname}
              onChange={handleChange}
            />
            <input
              type="text"
              placeholder="entrez votre prénom"
              name="lastname"
              value={FormValues.lastname}
              onChange={handleChange}
            />
            <p>{FormErrors.lastname}</p>
            <p>{FormErrors.firstname}</p>
          </div>
          <div>
            <input
              type="text"
              placeholder="entrez votre adresse "
              name="addresse"
              value={FormValues.addresse}
              onChange={handleChange}
            />
            <p>{FormErrors.addresse}</p>
          </div>
          <div>
            <input
              type="email"
              placeholder="entrez votre email"
              name="email"
              value={FormValues.email}
              onChange={handleChange}
            />
            <p>{FormErrors.email}</p>
          </div>
          <div>
            <input
              type="tel"
              placeholder="entrez votre numéro de téléphone"
              name="numero"
              value={FormValues.numero}
              onChange={handleChange}
            />
            <p>{FormErrors.numero}</p>
          </div>
        </div>

        <div className="announce">
          <h2>des informations concernant la formation :</h2>
          <div>
            <h4>Entrez une photo pour l'announce:</h4>
            <input
              type="file"
              placeholder="entrez une image"
              name="image"
              value={FormValues.image}
              onChange={handleChange}
            />
            <p>{FormErrors.image}</p>
          </div>
          <div>
            <input
              type="text"
              placeholder="entrez description"
              name="desc"
              value={FormValues.desc}
              onChange={handleChange}
            />
            <p>{FormErrors.desc}</p>
          </div>

          <div>
            <input
              type="text"
              placeholder="entrez le tarif"
              name="tarif"
              value={FormValues.tarif}
              onChange={handleChange}
            />
            <p>{FormErrors.tarif}</p>
          </div>
          <div>
            <input
              type="text"
              placeholder="entrez le lieu de la formation"
              name="lieu"
              value={FormValues.lieu}
              onChange={handleChange}
            />
            <p>{FormErrors.lieu}</p>
          </div>
          <div>
            <input
              type="text"
              placeholder="entrez le thème de la formation"
              name="theme"
              value={FormValues.theme}
              onChange={handleChange}
            />
            <p>{FormErrors.theme}</p>
          </div>

          <div>
            <h4>La catégorie de la formation :</h4>
            <select>
              <option>primaire</option>
              <option>collège</option>
              <option>lycée</option>
            </select>
          </div>
          <div>
            <h4>La modalité :</h4>
            <select>
              <option>online</option>
              <option>offline</option>
            </select>
          </div>
        </div>
        <button type="submit">publier</button>
      </form>
        </div>
        <div className="fr">
      <Footer></Footer>
      </div>
        </div>

  );
};

export default PublierAnnounce;
