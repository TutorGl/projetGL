import "./profile.css";

import { MapPin } from "tabler-icons-react";
import { ClockHour2 } from "tabler-icons-react";
import { Message } from "tabler-icons-react";
import { Heart } from "tabler-icons-react";
import Navbar from "./Navbar";
import logo from "./logo1.png";

import { BrandFacebook } from "tabler-icons-react";
import { BrandTwitter } from "tabler-icons-react";
import { BrandLinkedin } from "tabler-icons-react";
import { BrandInstagram } from "tabler-icons-react";
import "./user.jpg";
import "./cours1.png";
import "./cours2.png";
import "./cours3.jpg";
import "./Up arrow.png";

function Profile() {
  let activeStyle = {
    textDecoration: "underline",
  };

  let activeClassName = "underline";
  return (
    <div className="App">
      <Navbar />
      <div class="back">
        <img class="user " src={require("./user.jpg")} />
      </div>
      <div class="cont">
        <div class="inf">Ibtissam Benmessoud</div>
        <div class="inf">i_benmessoud@estin.dz</div>
        <button class="edit">Edit</button>
      </div>

      <h4>Mes publication</h4>
      <div class="pub">
        <div class="pubs">
          <div class="part1">
            <img class="cours1 " src={require("./cours1.png")} />
          </div>
          <div class="part2">
            {" "}
            <span style={{ fontWeight: "bold" }}>
              Cours en français pour le collége
            </span>{" "}
            <div class="txt">
              <MapPin size={20} strokeWidth={2} color={"black"} />
              Alger - Baba Hassen
            </div>
            <div class="txt">
              <ClockHour2 size={20} strokeWidth={2} color={"black"} />3 heures
            </div>
          </div>
          <div class="part3">
            {" "}
            <Message
              size={35}
              strokeWidth={2}
              color={"black"}
              style={{ marginLeft: 350 }}
            />
            <Heart size={35} strokeWidth={2} color={"black"} />
          </div>
        </div>
        <div class="pubs">
          <div class="part1">
            <img class="cours1 " src={require("./cours2.png")} />
          </div>
          <div class="part2">
            {" "}
            <span style={{ fontWeight: "bold" }}>
              Cours en Anglais en ligne pour primaire
            </span>{" "}
            <div class="txt">
              <MapPin size={20} strokeWidth={2} color={"black"} />
              Alger - Baba Hassen
            </div>
            <div class="txt">
              <ClockHour2 size={20} strokeWidth={2} color={"black"} />1 heures
            </div>
          </div>
          <div class="part3">
            {" "}
            <Message
              size={35}
              strokeWidth={2}
              color={"black"}
              style={{ marginLeft: 350 }}
            />
            <Heart size={35} strokeWidth={2} color={"black"} />
          </div>
        </div>
        <div class="pubs">
          <div class="part1">
            <img class="cours3 " src={require("./cours3.jpg")} />
          </div>
          <div class="part2">
            {" "}
            <span style={{ fontWeight: "bold" }}>
              Cours en français en ligne pour primaire
            </span>{" "}
            <div class="txt">
              <MapPin size={20} strokeWidth={2} color={"black"} />
              Alger - Baba Hassen
            </div>
            <div class="txt">
              <ClockHour2 size={20} strokeWidth={2} color={"black"} />
              1.5 heures
            </div>
          </div>
          <div class="part3">
            {" "}
            <Message
              size={35}
              strokeWidth={2}
              color={"black"}
              style={{ marginLeft: 350 }}
            />
            <Heart size={35} strokeWidth={2} color={"black"} />
          </div>
        </div>
      </div>
      <div className="footer">
        {" "}
        <div class="f1">
          <div cllassName="logo">
            <img src={logo} alt="logo" />
          </div>
          <p>
            TUTOR est un site web pour la publication et la consultation des
            annonces de soutien scolaire
          </p>
          <div class="list">
            <ul>
              <li>
                <a href="#">Acuiel</a>{" "}
              </li>
              <li>
                {" "}
                <a href="#">Liste de favouris</a>
              </li>
              <li>
                {" "}
                <a href="#">Cintcat us</a>
              </li>
              <li>
                {" "}
                <a href="#">Publier un announce</a>
              </li>{" "}
            </ul>
            ;
          </div>
          <div class="list">
            <ul>
              {" "}
              <li>
                <BrandFacebook size={20} strokeWidth={2} color={"#0081FE"} />
                <a href="#">facebook</a>
              </li>
              <li>
                <BrandTwitter size={20} strokeWidth={2} color={"#0081FE"} />
                <a href="#">Twitter</a>
              </li>
              <li>
                <BrandLinkedin size={20} strokeWidth={2} color={"#0081FE"} />
                <a href="#">Linkedin</a>
              </li>
              <li>
                {" "}
                <BrandInstagram size={20} strokeWidth={2} color={"#0081FE"} />
                <a href="#"> Instagram </a>
              </li>
            </ul>
          </div>
          <div class="up">
            {" "}
            <a href="#">
              <img src={require("./Up arrow.png")} />
            </a>
          </div>
        </div>
        <div class="right"> © 2022 Lift Media. All rights reserved.</div>
      </div>
    </div>
  );
}
export default Profile;
