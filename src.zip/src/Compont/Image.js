import React from "react";
import "../App.css";
import img from "./fond.png";

function Image() {
  return <img src={img} className="Image" alt="fond" />;
}

export default Image;
