import React from "react"
import Back from "../common/Back"
import "./inscription.css"

const inscription = () => {
  return (
    <>
      <section className='contact mb'>
        <Back name='' title=''  />
        
            
        
      </section>
    </>
  )
}

export default inscription